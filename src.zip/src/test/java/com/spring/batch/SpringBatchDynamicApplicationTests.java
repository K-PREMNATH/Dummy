package com.spring.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchDynamicApplicationTests {

    @Test
    void contextLoads() {
    }

}
